import React from "react"
import { StaticQuery, graphql } from "gatsby"

const getText = ({ children}) => (
    <StaticQuery
    query= {graphql`
        query MyQuery2 {
          allDataJson{
            edges {
              node {
                id
                title
                body
              }
            }
          }
        }
    `}

    render={ data => (
        <>
            <ul>{getJsonToText(data)}</ul>
        </>
    )}
  />
);

function getJsonToText (data){
  const jsonArray = [];
  data.allDataJson.edges.forEach(item =>
    jsonArray.push(<li key={item.node.id}>{item.node.id}</li>,
    <li key={item.node.title}>{item.node.title}</li>,
    <li key={item.node.body}>{item.node.body}</li>)
  );
  return jsonArray;
}

export default getText