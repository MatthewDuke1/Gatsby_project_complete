import React from "react"
import { Link } from "gatsby"

import GetText from "../components/queryn"
import Layout from "../components/layout"


const SecondPage = () => (

  <Layout>
    <h1>Hello Again</h1>
    <h2>Hi from Duke's custom page</h2>
    <p>For the assignment, I decided to use the fake JSON user data. <a href="https://jsonplaceholder.typicode.com/posts/1">https://jsonplaceholder.typicode.com/posts/1</a></p>
    <p>My local Json data is in Data > placeholder</p>
    <p>Let us grab a user:</p>
    <div>
      <GetText />
    </div>
    <Link to="/">Go back to the homepage</Link> <br />
    <Link to="/duke-page">Go to Duke's Custom Page!</Link>
  </Layout>
)

export default SecondPage



