import React from "react"
import { Link } from "gatsby"

import Layout from "../components/layout"
import Image from "../components/image"
import SEO from "../components/seo"
import Hero from "../components/hero"

const IndexPage = () => (
  <Layout>
    <div style={{ maxWidth: `800px`, maxHeight: `600px`, marginBottom: `1.45rem` }}>
      <Hero/>
    </div>
    <p>Hey there, this is Matthew Duke. This is pretty easy assignment. Thank you for the clear instructions!  </p>
    <p>Look forward to working with you Ameet and Nick!</p>
    <Link to="/duke-page">Go to Duke's custom page</Link><br />
    <hr />
    <SEO title="Home" />
    <h1>Hi people</h1>
    <p>Welcome to your new Gatsby site.</p>
    <p>Now go build something great.</p>
    <div style={{ maxWidth: `300px`, marginBottom: `1.45rem` }}>
      <Image />
    </div>
    <Link to="/page-2/">Go to page 2</Link><br />
    <Link to="/duke-page">OR Go to the Duke's Custom Page!</Link>
  </Layout>
)

export default IndexPage
