"use strict";

exports.polyfill = Component => Component;